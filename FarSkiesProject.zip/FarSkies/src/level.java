import javax.swing.*;
import java.util.ArrayList;

/**
 * Data structure for a level.
 */
public class level
{
    private final String name;
    private final ImageIcon icon;
    private final ArrayList<upgrade> availableUpgrades;

    /**
     * Constructor for a level.
     * @param name Name of the level.
     * @param icon Image to use for the level.
     * @param availableUpgrades Upgrades unlocked with this level.
     */
    public level(String name, ImageIcon icon, ArrayList<upgrade> availableUpgrades)
    {
        this.name = name;
        this.icon = icon;
        this.availableUpgrades = availableUpgrades;
    }

    /**
     * Method to test if two levels are equal.
     * @param o Object to compare to.
     * @return True if the objects and equal, false otherwise.
     */
    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }

        if (!(o instanceof upgrade)) {
            return false;
        }

        level l = (level)o;

        return this.name == l.name &&
                this.icon == l.icon &&
                this.availableUpgrades == l.availableUpgrades;
    }

    /**
     * Function to get the level name.
     * @return The name of the level.
     */
    public String GetName()
    {
        return name;
    }

    /**
     * Function to get the level icon.
     * @return The icon of the level.
     */
    public ImageIcon GetIcon()
    {
        return icon;
    }

    /**
     * Function to get the upgrades unlocked with the level.
     * @return The upgrades unlocked with the level.
     */
    public ArrayList<upgrade> GetAvailableUpgrades()
    {
        return availableUpgrades;
    }
}
