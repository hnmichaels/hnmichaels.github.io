import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * View for the main menu.
 */
public class mainMenuView extends JComponent {
    /**
     * Constructor for mainMenuView. Sets up the views elements.
     */
    public mainMenuView() {
        JLabel background1 = new JLabel();
        ImageIcon backgroundImage = new ImageIcon("resources/StarryNight.png");
        background1.setIcon(backgroundImage);
        background1.setBounds(0, 0, 1068, 767);
        //more for tiling
        JLabel background2 = new JLabel();
        background2.setIcon(backgroundImage);
        background2.setBounds(0, -363, 1068, 767);
        JLabel background3 = new JLabel();
        background3.setIcon(backgroundImage);
        background3.setBounds(534, 0, 1068, 767);
        JLabel background4 = new JLabel();
        background4.setIcon(backgroundImage);
        background4.setBounds(534, -363, 1068, 767);

        JLabel rocket = new JLabel();
        ImageIcon rocketImage = new ImageIcon("resources/RocketPixelArt.png");
        rocket.setIcon(rocketImage);
        rocket.setBounds(40,-40,400,1000);

        JButton play = new JButton("Launch Mission!");
        play.setBounds(485,500,200,50);//main menu play button positions
        play.setFont(new Font("Arial", Font.BOLD,20));
        play.setBackground(new Color(0,190,220));
        //play.setForeground(Color.white);
        play.setVerticalAlignment(SwingConstants.CENTER);
        play.setHorizontalAlignment(SwingConstants.CENTER);
        play.setOpaque(true);

        JLabel gameTitle = new JLabel("Far Skies");
        gameTitle.setBounds(385,-255,600,1000);
        gameTitle.setFont(new Font("Nanum Pen Script",Font.BOLD,130));
        gameTitle.setForeground(new Color (20, 100,220));


        play.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                Object source = actionEvent.getSource();
                if (source == play) {
                    Container parent = mainMenuView.this.getParent();
                    parent.remove(mainMenuView.this);
                    gameView gameView = new gameView();
                    gameView.setPreferredSize(parent.getSize());
                    parent.add(gameView);
                    parent.revalidate();
                    parent.repaint();
                }
            }
        });

        add(play);
        add(rocket);
        add(gameTitle);
        add(background1);
        add(background2);
        add(background3);
        add(background4);

    }
}
