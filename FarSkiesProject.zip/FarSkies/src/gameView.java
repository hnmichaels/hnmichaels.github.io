import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JComponent;
import javax.swing.*;
import java.util.*;
import java.util.Timer;

/**
 * View for the gameplay screen.
 */
public class gameView extends JComponent {
        /**
         * GameManager for the game.
         */
        GameManager gameManager = new GameManager();
        /**
         * UpgradeManager for the game.
         */
        upgradeManager upgradeManager = new upgradeManager();
        private Timer timer = new java.util.Timer();//CREATE TIMER OBJECT

        /**
         * Constructor for a brand new gameview.
         */
        public gameView()
        {
                ConstructLevel(GameManager.levels.get(0), new GameManager(), new upgradeManager());
        }

        /**
         * Constructor for gameview used when transitioning levels.
         * @param level Level to move to.
         * @param gameManagerIn Game manager for the game.
         * @param upgradeManagerIn Upgrade manager for the game.
         */
        public gameView(level level, GameManager gameManagerIn, upgradeManager upgradeManagerIn)
        {
                ConstructLevel(level, gameManagerIn, upgradeManagerIn);
        }

        /**
         * Creates all the elements in the game view.
         * @param level Level to move to.
         * @param gameManagerIn Game manager for the game.
         * @param upgradeManagerIn Upgrade manager for the game.
         */
        private void ConstructLevel(level level, GameManager gameManagerIn, upgradeManager upgradeManagerIn)
        {
                gameManager = gameManagerIn;
                upgradeManager = upgradeManagerIn;
                upgradeManager.ChangeLevel(level);

                //Icon for current planet
                JLabel currentPlanet = new JLabel();
                currentPlanet.setIcon(level.GetIcon());
                currentPlanet.setOpaque(true);
                currentPlanet.setBackground(Color.black);
                currentPlanet.setBounds(150,215,64,64);
                add(currentPlanet);

                //Text for current planet
                JLabel currentTitle = new JLabel("Current Planet:");
                currentTitle.setBounds(130,240,300,100);
                currentTitle.setFont(new Font("Nanum Pen Script", Font.BOLD, 20));
                add(currentTitle);

                //Current Planet Name
                JLabel currentName = new JLabel(level.GetName());
                currentName.setBounds(140,260,300,100);
                currentName.setFont(new Font("Nanum Pen Script", Font.BOLD,40));
                add(currentName);


                //Text for next planet
                JLabel nextTitle = new JLabel("Next Planet:");
                nextTitle.setBounds(840,240,300,100);
                nextTitle.setFont(new Font("Nanum Pen Script", Font.BOLD, 20));
                add(nextTitle);

                //Next Planet Name
                JLabel nextName = new JLabel(GameManager.levels.get(GameManager.levels.indexOf(level) + 1).GetName());
                nextName.setBounds(850,260,300,100);
                nextName.setFont(new Font("Nanum Pen Script", Font.BOLD,40));
                add(nextName);

                // Pause BUTTON=======================================
                JButton pause = new JButton("pause");
                pause.setBounds(930,625,75,30);
                add(pause);

                //---------------------- Timer
                final JLabel timeLabel = new JLabel();
                timeLabel.setPreferredSize(new Dimension(200,100));
                timeLabel.setText("Time: " + gameManager.GetCounter());
                timeLabel.setFont(new Font("Arial",Font.PLAIN,20));
                timeLabel.setForeground(new Color (255, 248, 141));
                timeLabel.setBounds(770,0,175,50);
                timeLabel.setHorizontalAlignment(SwingConstants.LEFT);
                timeLabel.setVerticalAlignment(SwingConstants.CENTER);

                //Click Per Second Display
                final JLabel clicksPerSecond = new JLabel();
                clicksPerSecond.setText("Clicks per Second: " + upgradeManager.CalculateClicksPerSecond());
                clicksPerSecond.setFont(new Font("Arial",Font.PLAIN,20));
                clicksPerSecond.setForeground(new Color (255, 248, 141));
                clicksPerSecond.setBounds(425,0,500,50);
                clicksPerSecond.setHorizontalAlignment(SwingConstants.LEFT);
                clicksPerSecond.setVerticalAlignment(SwingConstants.CENTER);


                //================================================
                //Fuel Cell Count TEXT
                //==============================
                final JLabel clickCount = new JLabel();
                clickCount.setPreferredSize(new Dimension(200,100));
                clickCount.setText("Fuel Cells: " + gameManager.GetClicks());
                clickCount.setFont(new Font("Arial",Font.PLAIN,20));
                clickCount.setForeground(new Color (255, 248, 141));
                clickCount.setBounds(180,0,500,50);
                clickCount.setHorizontalAlignment(SwingConstants.LEFT);
                clickCount.setVerticalAlignment(SwingConstants.CENTER);

                //ROCKET Button
                //=====================
                JButton button = new JButton();//put within game view
                ImageIcon rocket = new ImageIcon("resources/rocket.gif");
                button.setIcon(rocket);
                button.setOpaque(true);//new
                button.setContentAreaFilled(false);
                button.setBorderPainted(false);
                button.setBounds(415,60,240,500);

                //Upgrade Rectangle
                JLabel upgradeRectangle = new JLabel();
                upgradeRectangle.setBackground(Color.black);
                upgradeRectangle.setOpaque(true);
                upgradeRectangle.setBounds(0,540,875,200);

                //Timer/Counter Rectangle
                JLabel headRectangle = new JLabel();
                headRectangle.setBackground(Color.black);
                headRectangle.setOpaque(true);
                headRectangle.setBounds(0,0,1200,50);

                //Pause area rectangle
                JLabel pauseRectangle = new JLabel();
                pauseRectangle.setBackground(new Color(155,52,10));
                pauseRectangle.setOpaque(true);
                pauseRectangle.setBounds(875,540,300,200);

                //Rocket Rectangle
                JLabel rocketRectangle = new JLabel();
                rocketRectangle.setBackground(new Color(20,100,220));
                rocketRectangle.setOpaque(true);
                rocketRectangle.setBounds(285,50,515,540);

                //=============================================
                //Pause Button
                //=============================================
                pause.addActionListener(new ActionListener() {//add universal quantifer so u dont have to use play and pause
                        @Override
                        public void actionPerformed(ActionEvent actionEvent) {
                                Object source = actionEvent.getSource();
                                if (source == pause) {
                                        gameManager.SetIsPaused(true);
                                        Container parent = gameView.this.getParent();
                                        parent.remove(gameView.this);
                                        pauseMenuView pauseView = new pauseMenuView(gameView.this);
                                        pauseView.setPreferredSize(parent.getSize());
                                        parent.add(pauseView);
                                        parent.revalidate();
                                        parent.repaint();
                                        parent.setVisible(true);
                                }
                        }
                });

                // button.setMaximumSize(new Dimension(1000,200));
                button.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent actionEvent) {
                                gameManager.SetClicks(gameManager.GetClicks() + 1);
                                clickCount.setText("Fuel Cells: "+gameManager.GetClicks()+" " );
                        }
                });//UPGRADE BUTTON

                timer.schedule(new TimerTask() {
                        @Override
                        public void run() {
                                if (!gameManager.IsPaused()) {
                                        gameManager.SetCounter(gameManager.GetCounter() + 1);
                                        timeLabel.setText("Time:" + " " + gameManager.GetCounter());
                                }
                        }
                }, 1000,1000);

                for (int i = 0; i < level.GetAvailableUpgrades().size(); i++)
                {
                        upgrade upgrade = level.GetAvailableUpgrades().get(i);

                        JButton upgradeButton = new JButton();//put within game view
                        upgradeButton.setIcon(upgrade.GetIcon());
                        upgradeButton.setOpaque(true);
                        upgradeButton.setBackground(Color.black);
                        JLabel upgradePrice = new JLabel("X" + String.valueOf(upgrade.GetBasePrice()));
                        JLabel totalUpgrade = new JLabel("Total Acquired: " + String.valueOf(upgradeManager.GetNumUpgrades(upgrade)));

                        if(!upgrade.IsLevelAdvance()){
                                upgradeButton.setBorderPainted(true);

                                upgradeButton.setBounds(375,550 + (i * 64),64,64);
                                upgradePrice.setBounds(450,550 + (i * 64), 100, 64);
                                upgradePrice.setFont(new Font("Nanum Pen Script", Font.BOLD,20));
                                upgradePrice.setForeground(Color.white);

                                totalUpgrade.setBounds(550,550 + (i * 64),800, 64);
                                totalUpgrade.setFont(new Font("Nanum Pen Script", Font.BOLD,20));
                                totalUpgrade.setForeground(Color.white);
                                add(totalUpgrade);

                                JLabel upgradeName = new JLabel(upgrade.GetName());
                                upgradeName.setBounds(50,550 + (i * 64),300, 64);
                                upgradeName.setFont(new Font("Nanum Pen Script", Font.BOLD,30));
                                upgradeName.setForeground(Color.white);
                                add(upgradeName);
                        }
                        else{
                                upgradeButton.setBorderPainted(false);

                                upgradeButton.setBounds(850,215,64,64);
                                upgradePrice.setBounds(850,300,100,64);
                        }
                        add(upgradeButton,BorderLayout.SOUTH);//add upgrade to panel
                        add(upgradePrice);

                        upgradeButton.addActionListener(new ActionListener() {
                                public void actionPerformed(ActionEvent actionEvent) {
                                        if (gameManager.GetClicks() >= upgrade.GetBasePrice()) {
                                                upgradeManager.BuyUpgrade(upgrade);
                                                gameManager.SetClicks(gameManager.GetClicks() - upgrade.GetBasePrice());//subtract the cost of the upgrade
                                                clickCount.setText("Fuel Cells: " + gameManager.GetClicks());
                                                totalUpgrade.setText("Total Acquired: " + String.valueOf(upgradeManager.GetNumUpgrades(upgrade)));
                                                clicksPerSecond.setText("Clicks per Second: " + upgradeManager.CalculateClicksPerSecond());

                                                if (upgrade.IsLevelAdvance())
                                                {
                                                        level nextLevel = GameManager.levels.get(GameManager.levels.indexOf(level) + 1);
                                                        Container parent = gameView.this.getParent();
                                                        parent.remove(gameView.this);

                                                        if (GameManager.levels.get(GameManager.levels.size() - 1) == nextLevel)
                                                        {
                                                                winningView winningView = new winningView();
                                                                winningView.setPreferredSize(parent.getSize());
                                                                parent.add(winningView);
                                                        }
                                                        else
                                                        {
                                                                gameView gameView = new gameView(
                                                                        nextLevel,
                                                                        gameManager,
                                                                        upgradeManagerIn
                                                                );
                                                                gameView.setPreferredSize(parent.getSize());
                                                                parent.add(gameView);
                                                        }

                                                        parent.revalidate();
                                                        parent.repaint();
                                                        timer.cancel();
                                                }
                                        }
                                }
                        });
                }

                timer.schedule(new TimerTask() {
                        @Override
                        public void run() {
                                if (!gameManager.IsPaused()) {
                                        gameManager.SetClicks(gameManager.GetClicks() + upgradeManager.CalculateClicksPerSecond());
                                        clickCount.setText("Fuel Cells: " + gameManager.GetClicks());
                                }
                        }
                }, 1000, 1000);

                add(clicksPerSecond);
                add(clickCount);
                add(timeLabel);
                add(button);
                add(upgradeRectangle);
                add(headRectangle);
                add(pauseRectangle);
                add(rocketRectangle);


        }
}
