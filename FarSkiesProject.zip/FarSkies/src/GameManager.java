import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * Manages the state of the game.
 */
public class GameManager
{
    private boolean isPaused = false;
    private long clicks = 0;
    private int counter=0;

    /**
     * List of levels in the game, in order. Essentially dictates the structure of the game.
     */
    public static final ArrayList<level> levels = new ArrayList<level>(Arrays.asList(
        new level("Earth", GetImageWithSize("resources/EarthyPlanet.PNG", 69, 64), new ArrayList<upgrade>(Arrays.asList(
                new upgrade("Bolts", 10, 10, GetImageWithSize("resources/Bolts.png", 64, 64)),
                new upgrade("Nail", 100, 50, GetImageWithSize("resources/Nail.png", 64, 64)),
                new upgrade("Screw", 1000, 100, GetImageWithSize("resources/Screw.png", 64, 64)),
                new upgrade("Mars", 10000, GetImageWithSize("resources/Mars.png", 64, 64))
        ))),
        new level("Mars", GetImageWithSize("resources/Mars.png", 64, 64), new ArrayList<upgrade>(Arrays.asList(
                new upgrade("Mars Element", 5000, 200, GetImageWithSize("resources/MarsElement.png", 64, 64)),
                new upgrade("Rover Panel", 10000, 1000, GetImageWithSize("resources/RoverPanel.png", 64, 64)),
                new upgrade("Mars Metal", 25000, 1750, GetImageWithSize("resources/MarsMetal.png", 64, 64)),
                new upgrade("Jupiter", 100000, GetImageWithSize("resources/Jupiter.png", 64, 64))
        ))),
        new level("Jupiter", GetImageWithSize("resources/Jupiter.png", 64, 64), new ArrayList<upgrade>(Arrays.asList(
                new upgrade("Red Spot Energy", 50000, 10000, GetImageWithSize("resources/GreatRedSpotEnergy.png", 64, 64)),
                new upgrade("Voyager Satellite", 100000, 25000, GetImageWithSize("resources/VoyagerSatellite.png", 64, 64)),
                new upgrade("Ball of Gas", 1000000, 75000, GetImageWithSize("resources/BallofGasJ.png", 64, 64)),
                new upgrade("Saturn", 10000000, GetImageWithSize("resources/Saturn.png", 64, 64))
        ))),
        new level("Saturn", GetImageWithSize("resources/Saturn.png", 64, 64), new ArrayList<upgrade>(Arrays.asList(
                new upgrade("Jar of Ring Dust", 1000000, 100000, GetImageWithSize("resources/JarRingDust.png", 64, 64)),
                new upgrade("Voyager Pod", 2500000, 1000000, GetImageWithSize("resources/VoyagerPod.png", 64, 64)),
                new upgrade("Random Ice", 5000000, 2000000, GetImageWithSize("resources/RandomIce.png", 64, 64)),
                new upgrade("Alpha Centauri", 100000000, GetImageWithSize("resources/AlphaCentauri.png", 64, 64))
        ))),
        new level("Alpha Centauri", GetImageWithSize("resources/AlphaCentauri.png", 64, 64), new ArrayList<upgrade>(Arrays.asList(
        )))
    ));

    /**
     * Used to resize an image.
     * @param file Location of image.
     * @param width Desired width.
     * @param height Desired height.
     * @return Resized icon.
     */
    public static ImageIcon GetImageWithSize(String file, int width, int height)
    {
        var imageIcon = new ImageIcon(file);
        return new ImageIcon(imageIcon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH));
    }

    /**
     * Used to get the value of isPaused.
     * @return Value of isPaused.
     */
    public boolean IsPaused()
    {
        return isPaused;
    }

    /**
     * Used to set the value of isPaused.
     * @param isPaused Value to set isPaused to.
     */
    public void SetIsPaused(boolean isPaused)
    {
        this.isPaused = isPaused;
    }

    /**
     * Used to get the value of clicks.
     * @return Value of clicks.
     */
    public long GetClicks()
    {
        return clicks;
    }

    /**
     * Used to set the value of clicks.
     * @param clicks Value to set clicks to.
     */
    public void SetClicks(long clicks)
    {
        this.clicks = clicks;
    }

    /**
     * Used to get the value of counter.
     * @return Value of counter.
     */
    public int GetCounter()
    {
        return counter;
    }

    /**
     * Used to set the value of counter.
     * @param counter Value to set counter to.
     */
    public void SetCounter(int counter)
    {
        this.counter = counter;
    }
}
