import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * View that displays when player wins.
 */
public class winningView extends JComponent {
    /**
     * Constructor for winningView. Sets up the views elements.
     */
    public winningView(){
        JLabel background1 = new JLabel();
        ImageIcon backgroundImage = new ImageIcon("resources/StarryNight.png");
        background1.setIcon(backgroundImage);
        background1.setBounds(0, 0, 1068, 767);
        //more for tiling
        JLabel background2 = new JLabel();
        background2.setIcon(backgroundImage);
        background2.setBounds(0, -363, 1068, 767);
        JLabel background3 = new JLabel();
        background3.setIcon(backgroundImage);
        background3.setBounds(534, 0, 1068, 767);
        JLabel background4 = new JLabel();
        background4.setIcon(backgroundImage);
        background4.setBounds(534, -363, 1068, 767);

        //Alpha Centauri Icon on winning screen
        JLabel alphaCentauri = new JLabel();
        ImageIcon alphaCImage = GameManager.GetImageWithSize("resources/AlphaCentauri.png", 1600, 1600);
        alphaCentauri.setIcon(alphaCImage);
        //lphaCentauri.setBackground(Color.blue);
        //alphaCentauri.setOpaque(true);
        alphaCentauri.setBounds(300,-600,1600,1600);

        //You Win Icon on winning screen
        JLabel youWon = new JLabel();
        ImageIcon winner = GameManager.GetImageWithSize("resources/YouWin.png", 480, 480);
        youWon.setIcon(winner);
        youWon.setBounds(100,100,480,480);

        //Return Home button
        JButton returnHome = new JButton("Mission Accomplished!");
        returnHome.setBounds(375,500,250,50);//main menu play button positions
        returnHome.setVerticalAlignment(SwingConstants.CENTER);
        returnHome.setHorizontalAlignment(SwingConstants.CENTER);
        returnHome.setOpaque(true);

        //This method allows for the return home button to be clicked and return to main view
        returnHome.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                Object source = actionEvent.getSource();
                if (source == returnHome) {
                    Container parent = winningView.this.getParent();
                    parent.remove(winningView.this);
                    mainMenuView mainView = new mainMenuView();
                    mainView.setPreferredSize(parent.getSize());
                    parent.add(mainView);
                    parent.revalidate();
                    parent.repaint();
                }
            }
        });

        add(youWon);
        add(alphaCentauri);
        add(returnHome);
        add(background1);
        add(background2);
        add(background3);
        add(background4);
    }
}
