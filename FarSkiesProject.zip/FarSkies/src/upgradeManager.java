import java.util.HashMap;
import java.util.Map;

/**
 * Class that manages keeping track of upgrades.
 */
public class upgradeManager
{
    private HashMap<upgrade, Integer> upgrades = new HashMap<upgrade, Integer>();//upgrade is the key, integer is the value

    /**
     * Handles adding to the upgrade list when the level is changed.
     * @param level Level to change to.
     */
    public void ChangeLevel(level level)
    {
        for (upgrade upgrade : level.GetAvailableUpgrades())//class Upgrade object name: upgrade : array list
        {
            upgrades.put(upgrade, 0);
        }
    }

    /**
     * Used to buy an upgrade for the player.
     * @param upgrade Upgrade to buy.
     */
    public void BuyUpgrade(upgrade upgrade)
    {
        upgrades.put(upgrade, upgrades.get(upgrade) + 1);
    }

    /**
     * Calculates total clicks per second the player has.
     * @return The clicks per second the player has.
     */
    public long CalculateClicksPerSecond()
    {
        long cps = 0;//clicks per sec
        for (Map.Entry<upgrade, Integer> upgradeSet : upgrades.entrySet())
        {
            cps += upgradeSet.getValue() * upgradeSet.getKey().GetClicksPerSecond();
        }
        return cps;
    }

    /**
     * Gets the number of a specific upgrade a player has.
     * @param upgrade The upgrade in question.
     * @return The number of upgrades owned.
     */
    public int GetNumUpgrades(upgrade upgrade)
    {
        return upgrades.get(upgrade);
    }
}
