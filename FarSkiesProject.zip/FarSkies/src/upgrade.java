import javax.swing.*;

/**
 * Data structure that represents an upgrade.
 */
public class upgrade
{
    private final String name;
    private final long basePrice;
    private final long clicksPerSecond;
    private final boolean advanceLevel;
    private final ImageIcon icon;

    /**
     * Constructor for upgrade that is used for a standard upgrade.
     * @param name Name of the upgrade.
     * @param basePrice Base price of the upgrade.
     * @param clicksPerSecond Clicks per second of the upgrade.
     * @param icon Icon for the upgrade.
     */
    public upgrade(String name, long basePrice, long clicksPerSecond, ImageIcon icon)
    {
        this.name = name;
        this.basePrice = basePrice;
        this.clicksPerSecond = clicksPerSecond;
        this.icon = icon;
        this.advanceLevel = false;
    }

    /**
     * Constructor for upgrade that is used for a level advancement upgrade.
     * @param name Name of the upgrade.
     * @param basePrice Base price of the upgrade.
     * @param icon Icon for the upgrade.
     */
    public upgrade(String name, long basePrice, ImageIcon icon) // level upgrade
    {
        this.name = name;
        this.basePrice = basePrice;
        this.clicksPerSecond = 0;
        this.icon = icon;
        this.advanceLevel = true;
    }

    /**
     * Method to test if two levels are equal.
     * @param o Object to compare to.
     * @return True if the objects and equal, false otherwise.
     */
    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }

        if (!(o instanceof upgrade)) {
            return false;
        }

        upgrade u = (upgrade)o;

        return this.name == u.name &&
                this.basePrice == u.basePrice &&
                this.clicksPerSecond == u.clicksPerSecond &&
                this.icon == u.icon &&
                this.advanceLevel == u.advanceLevel;
    }

    /**
     * Used to get the value of name.
     * @return Value of name.
     */
    public String GetName()
    {
        return name;
    }

    /**
     * Used to get the value of basePrice.
     * @return Value of basePrice.
     */
    public long GetBasePrice()
    {
        return basePrice;
    }

    /**
     * Used to get the value of clicksPerSecond.
     * @return Value of clicksPerSecond.
     */
    public long GetClicksPerSecond()
    {
        return clicksPerSecond;
    }

    /**
     * Used to get the value of icon.
     * @return Value of icon.
     */
    public ImageIcon GetIcon()
    {
        return icon;
    }

    /**
     * Used to get the value of advanceLevel.
     * @return Value of advanceLevel.
     */
    public boolean IsLevelAdvance()
    {
        return advanceLevel;
    }
}
