import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * View for the pause menu.
 */
public class pauseMenuView extends JComponent {
    /**
     * Constructor for pauseMenuView. Sets up the views elements.
     * @param gameView GameView to preserve while game is paused.
     */
    public pauseMenuView(gameView gameView) {
        //THis section codes the background of our menus

        JLabel background1 = new JLabel();
        ImageIcon backgroundImage = new ImageIcon("resources/StarryNight.png");
        background1.setIcon(backgroundImage);
        background1.setBounds(0, 0, 1068, 767);
        //more for tiling
        JLabel background2 = new JLabel();
        background2.setIcon(backgroundImage);
        background2.setBounds(0, -363, 1068, 767);
        JLabel background3 = new JLabel();
        background3.setIcon(backgroundImage);
        background3.setBounds(534, 0, 1068, 767);
        JLabel background4 = new JLabel();
        background4.setIcon(backgroundImage);
        background4.setBounds(534, -363, 1068, 767);

        //Return to game button that returns to the game

        JButton returnGame = new JButton("Return to Game");
        returnGame.setBounds(415, 275, 200, 50);//main menu play button positions
        returnGame.setVerticalAlignment(SwingConstants.CENTER);
        returnGame.setHorizontalAlignment(SwingConstants.CENTER);
        returnGame.setOpaque(true);

        returnGame.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(ActionEvent actionEvent) {
                 Object source = actionEvent.getSource();
                 if (source == returnGame) {
                     Container parent = pauseMenuView.this.getParent();
                     parent.remove(pauseMenuView.this);
                     gameView.setPreferredSize(parent.getSize());
                     gameView.gameManager.SetIsPaused(false);
                     parent.add(gameView);
                     parent.revalidate();
                     parent.repaint();
                     parent.setVisible(true);
                 }
             }
        });
        //Quit game button that returns to main menu
        JButton quitGame = new JButton("Return to Main Menu");
        quitGame.setBounds(415, 425, 200, 50);//main menu play button positions
        quitGame.setVerticalAlignment(SwingConstants.CENTER);
        quitGame.setHorizontalAlignment(SwingConstants.CENTER);
        quitGame.setOpaque(true);

        quitGame.addActionListener(new ActionListener() {//add universal quantifer so u dont have to use play and pause
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                Object source = actionEvent.getSource();
                if (source == quitGame) {
                    Container parent = pauseMenuView.this.getParent();
                    parent.remove(pauseMenuView.this);
                    mainMenuView mainView = new mainMenuView();
                    mainView.setPreferredSize(parent.getSize());
                    parent.add(mainView);
                    parent.revalidate();
                    parent.repaint();
                    parent.setVisible(true);
                }
            }
        });

        //Text to say it is the pause menu
        JLabel pauseTitle = new JLabel("Game is Paused!");
        pauseTitle.setBounds(230,-300,600,1000);
        pauseTitle.setFont(new Font("Nanum Pen Script",Font.BOLD,70));
        pauseTitle.setVerticalAlignment(SwingConstants.CENTER);
        pauseTitle.setHorizontalAlignment(SwingConstants.CENTER);
        pauseTitle.setForeground(new Color (20, 100,220));
        //Include the still picture of the rocket

        add(returnGame);
        add(quitGame);
        add(pauseTitle);
        add(background1);
        add(background2);
        add(background3);
        add(background4);
    }
}
